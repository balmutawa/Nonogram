/**
 * Tablet is the child class of the PortableElectronics class.
 *
 * @author Basel Almutawa
 * @version 1.0 and Sep 21st 2021 
 */
public class Tablet extends PortableElectronics{
    public double screenSize;

    /**
     * Constructor
     * @param eManufacturer
     * @param ePrice
     * @param eWeight
     * @param pPatteryType 
     */
    public Tablet(String eManufacturer, double ePrice, double eWeight, String pPatteryType) {
        super(eManufacturer, ePrice, eWeight, pPatteryType);
    }

    /**
     * 
     * @return screenSize
     */
    public double getScreenSize() {
        return screenSize;
    }

    /**
     * 
     * @param tscreenSize 
     */
    public void setScreenSize(double tscreenSize) {
        this.screenSize = tscreenSize;
    }
/**
     * 
     * @return toString() of the object
     */
    @Override
    public String toString() {
        return "Manufacturer: " + manufacturer + ", Price: " + price + ", Weight: " 
                + weight+", Battery Type: "+batteryType + ", screenSize: " + screenSize;
    }
    
    
    
}
