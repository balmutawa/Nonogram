/**
 * AlarmClock is the child class of the Clock class.
 *
 * @author Basel Almutawa
 * @version 1.0 and Sep 21st 2021 
 */
public class AlarmClock extends Clock {

    protected String alarmTime;

    /**
     * Constructor
     *
     * @param hManufacturer
     * @param hPrice
     * @param hWeight
     * @param hRoom
     * @param cCurrentTime
     * @param aAlarmTime
     */
    public AlarmClock(String hManufacturer, double hPrice, double hWeight, String hRoom, String cCurrentTime, String aAlarmTime) {
        super(hManufacturer, hPrice, hWeight, hRoom, cCurrentTime);
        this.alarmTime = aAlarmTime;
    }

    /**
     *
     * @return alarm time
     */
    public String getAlarmTime() {
        return alarmTime;
    }

    /**
     *
     * @param aAlarmTime
     */
    public void setAlarmTime(String aAlarmTime) {
        this.alarmTime = aAlarmTime;
    }

    /**
     *
     * @return toString() of the object
     */
    @Override
    public String toString() {
        return "Manufacturer: " + manufacturer + ", Price: " + price + ", Weight: "
                + weight + ", Room: " + room + ", Time: " + currentTime + "alarmTime:" + alarmTime;
    }

}
