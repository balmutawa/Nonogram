/**
 * WallClock is the child class of the Clock class.
 *
 * @author Basel Almutawa
 * @version 1.0 and Sep 21st 2021 
 */
public class WallClock extends Clock {

    /**
     * Constructor
     * @param hManufacturer
     * @param hPrice
     * @param hWeight
     * @param hRoom
     * @param cCurrentTime 
     */
    public WallClock(String hManufacturer, double hPrice, double hWeight, String hRoom, String cCurrentTime) {
        super(hManufacturer, hPrice, hWeight, hRoom, cCurrentTime);
    }

    /**
     *
     * @return toString() of the object
     */
    @Override
    public String toString() {
        return "Manufacturer: " + manufacturer + ", Price: " + price + ", Weight: " + weight + ", Room: " + room + ", Time: " + currentTime;
    }

}
