/**
 * PortableElectronics is the child class of the Electronics class.
 *
 * @author Basel Almutawa
 * @version 1.0 and Sep 21st 2021 
 */
public class PortableElectronics extends Electronics {

    protected String batteryType;

    /**
     * Constructor
     *
     * @param eManufacturer
     * @param ePrice
     * @param eWeight
     * @param pPatteryType
     */
    public PortableElectronics(String eManufacturer, double ePrice, double eWeight, String pPatteryType) {
        super(eManufacturer, ePrice, eWeight);
        this.batteryType = pPatteryType;
    }

    /**
     *
     * @return battery type
     */
    public String getBatteryType() {
        return batteryType;
    }

    /**
     *
     * @param pPatteryType
     */
    public void setBatteryType(String pPatteryType) {
        this.batteryType = pPatteryType;
    }

    /**
     *
     * @return toString() of the object
     */
    @Override
    public String toString() {
        return "Manufacturer: " + manufacturer + ", Price: " + price + ", Weight: " + weight + ", Battery Type: " + batteryType;
    }

}
