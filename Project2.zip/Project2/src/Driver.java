/**
 * Driver class
 *
 * @author Basel Almutawa
 * @version 1.0 and Sep 21st 2021 
 */
public class Driver {
    public static void main(String []args){
        Clock clock1 = new Clock("Quartz", 100, 1, "Living", "10:00 AM");
        Printer printer = new Printer("HP", 200, 20, "Study", 300, false, false);
        AlarmClock aClock = new AlarmClock("Timex", 200, 1, "Bedroom", "7:00 PM", "6:00 AM");
        WallClock wClock = new WallClock("Citizen", 50, 3, "Living", "9:00 PM");
        Tablet tab = new Tablet("Lenovo", 400, 2, "Li-ion");
        CellPhone phone = new CellPhone("Apple", 800, 0.4, "Li-ion");
        System.out.println("-----------------------------------------------------------------------------");
        System.out.println("Printing regular object");
        System.out.println("-----------------------------------------------------------------------------");
        System.out.println(clock1);
        System.out.println(printer);
        System.out.println(aClock);
        System.out.println(wClock);
        System.out.println(tab);
        System.out.println(phone);
        System.out.println("-----------------------------------------------------------------------------");
        System.out.println("Assigning to superclass Electronics then checking data: Runtime polymorphsim");
        System.out.println("-----------------------------------------------------------------------------");
        Electronics objSuper = clock1;
        System.out.println(objSuper);
        objSuper = printer;
        System.out.println(objSuper);
        objSuper = aClock;
        System.out.println(objSuper);
        objSuper = wClock;
        System.out.println(objSuper);
        objSuper = tab;
        System.out.println(objSuper);
        objSuper = phone;
        System.out.println(objSuper);
        System.out.println("-----------------------------------------------------------------------------");
        System.out.println("Play with some objects and its method");
        System.out.println("-----------------------------------------------------------------------------");
        tab.screenSize = 8.4;
        System.out.println(tab);
        System.out.println("Printer: status: "+printer.printerStatus());
        printer.loadInk();
        printer.loadPaper();
        System.out.println("Printer: status: "+printer.printerStatus());
        System.out.println("-----------------------------------------------------------------------------");
    }
}
