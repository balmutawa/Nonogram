/**
 * HomeAppliances is the child class of the Electronics class.
 *
 * @author Basel Almutawa
 * @version 1.0 and Sep 21st 2021 
 */
public class HomeAppliances extends Electronics
{
    protected String room;
    /**
     * Constructor 
     * @param hManufacturer
     * @param hPrice
     * @param hWeight
     * @param hRoom 
     */
    HomeAppliances(String hManufacturer, double hPrice, double hWeight, String hRoom)
    {
        super(hManufacturer, hPrice, hWeight);
        room = hRoom;
    }
    
    /**
     * 
     * @return room
     */
    public String getRoom()
    {
        return room;
    }
    
    /**
     * 
     * @param hRoom 
     */
    public void setRoom(String hRoom)
    {
        room = hRoom;
    }
    /**
     * 
     * @return toString() of the object
     */
    public String toString()
    {
        return "Manufacturer: " + manufacturer + ", Price: " + price + ", Weight: " + weight + ", Room: " + room;
    }
}
