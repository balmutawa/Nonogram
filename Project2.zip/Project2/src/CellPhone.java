/**
 * CellPhone is the child class of the PortableElectronics class.
 *
 * @author Basel Almutawa
 * @version 1.0 and Sep 21st 2021 
 */
public class CellPhone extends PortableElectronics {

    protected String phoneNumber;

    /**
     * Constructor
     *
     * @param eManufacturer
     * @param ePrice
     * @param eWeight
     * @param pPatteryType
     */
    public CellPhone(String eManufacturer, double ePrice, double eWeight, String pPatteryType) {
        super(eManufacturer, ePrice, eWeight, pPatteryType);
    }

    /**
     *
     * @return phone number
     */
    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String cPhoneNumber) {
        this.phoneNumber = cPhoneNumber;
    }

    /**
     *
     * @return toString() of the object
     */
    @Override
    public String toString() {
        return "Manufacturer: " + manufacturer + ", Price: " + price
                + ", Weight: " + weight + ", Battery Type: " + batteryType + ", Phone Number:" + phoneNumber;
    }

}
