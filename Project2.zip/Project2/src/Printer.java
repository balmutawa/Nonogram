/**
 * Printer is the child class of the HomeAppliances class.
 *
 * @author Basel Almutawa
 * @version 1.0 and Sep 21st 2021 
 */
public class Printer extends HomeAppliances {

    protected int dotsPerInch;
    protected boolean paperLoaded;
    protected boolean inkLoaded;

    /**
     * Constructor
     *
     * @param hManufacturer
     * @param hPrice
     * @param hWeight
     * @param hRoom
     * @param dp
     * @param paper
     * @param ink
     */
    public Printer(String hManufacturer, double hPrice, double hWeight, String hRoom, int dp, boolean paper, boolean ink) {
        super(hManufacturer, hPrice, hWeight, hRoom);
        this.dotsPerInch = dp;
        this.paperLoaded = paper;
        this.inkLoaded = ink;
    }

    /**
     * set paper is loaded
     */
    public void loadPaper() {
        this.paperLoaded = true;
    }

    /**
     * set ink is loaded
     */
    public void loadInk() {
        inkLoaded = true;
    }

    /**
     *
     * @param ink
     */
    public void setInkLoaded(boolean ink) {
        this.inkLoaded = ink;
    }

    /**
     *
     * @return isloaded
     */
    public boolean getInkLoaded() {
        return this.inkLoaded;
    }

    /**
     *
     * @return status of the printer
     */
    public boolean printerStatus() {
        return this.inkLoaded && this.paperLoaded;
    }

    /**
     *
     * @return toString() of the object
     */
    @Override
    public String toString() {
        return "Manufacturer: " + manufacturer + ", Price: " + price + ", Weight: " + weight + ", Room: " + room
                + ", DotsPerInch: " + dotsPerInch + ", PaperLoaded: " + paperLoaded + ", InkLoaded: " + inkLoaded;
    }

}
