/**
 * Clock is the child class of the HomeAppliances class.
 *
 * @author Basel Almutawa
 * @version 1.0 and Sep 21st 2021 
 */
public class Clock extends HomeAppliances {

    protected String currentTime;

    /**
     * Constructor
     *
     * @param hManufacturer
     * @param hPrice
     * @param hWeight
     * @param hRoom
     * @param cCurrentTime
     */
    public Clock(String hManufacturer, double hPrice, double hWeight, String hRoom, String cCurrentTime) {
        super(hManufacturer, hPrice, hWeight, hRoom);
        this.currentTime = cCurrentTime;
    }

    /**
     *
     * @return time
     */
    public String getTime() {
        return currentTime;
    }

    /**
     *
     * @param cCurrentTime
     */
    public void setTime(String cCurrentTime) {
        this.currentTime = cCurrentTime;
    }

    /**
     *
     * @return toString() of the object
     */
    @Override
    public String toString() {
        return "Manufacturer: " + manufacturer + ", Price: " + price + ", Weight: " + weight + ", Room: " + room + ", Time: " + currentTime;
    }

}
