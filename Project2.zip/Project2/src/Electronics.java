
/**
 * Electronics is the base class of all electronics.
 * It keep track of menufacturers, price and weight
 *
 * @author Basel Almutawa
 * @version 1.0 and Sep 21st 2021 
 */
public class Electronics
{
    protected String manufacturer;
    protected double price;
    protected double weight;
    
    /**
     * Constructor
     * @param eManufacturer
     * @param ePrice
     * @param eWeight 
     */
    Electronics(String eManufacturer, double ePrice, double eWeight)
    {
        manufacturer = eManufacturer;
        price = ePrice;
        weight = eWeight;
    }

    /**
     * 
     * @return String
     */
    public String getManu() {
        return manufacturer;
    }

    /**
     * 
     * @param manufacturer 
     */
    public void setManu(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    /**
     * 
     * @return double
     */
    public double getWeight() {
        return weight;
    }

    /**
     * 
     * @param weight 
     */
    public void setWeight(double weight) {
        this.weight = weight;
    }
    /**
     * 
     * @return double
     */
    public double getPrice()
    {
        return price;
    }
    /**
     * 
     * @param ePrice 
     */
    public void setPrice(double ePrice)
    {
        price = ePrice;
    }
    
    /**
     * 
     * @return toString() of the object
     */
    public String toString()
    {
        return "Manufacturer: " + manufacturer + ", Price: " + price + ", Weight: " + weight;
    }
}
