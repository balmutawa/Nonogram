package phoneDirectory;

import java.util.Scanner;
/**
 *Driver class
 *
 * Basel Almutawa
 * sep/13
 */

public class Driver
{
    public static void main(String[] args)
    {
        
        int menuOption; 
        String name = null, address = null, buffer = null;
        int phone = 0;
        
        Scanner in= new Scanner (System.in);
        Directory dir=new Directory (10);
        dir.entries[0] = new Entry(name, buffer, address, phone);
        
        while (true)
        {
        	//display menu and user choices
        	System.out.println ("1. Insert new record in directory : ");
 	        System.out.println ("2. Display record: ");
 	        System.out.println ("3. Search record: ");
 	        System.out.println ("4. Exit ");
 	        menuOption = in.nextInt();
 	        
 	        boolean ex=false;
 	        		
 	        switch (menuOption)
 	        {
	 	       //perform function according to the different user choices 
		        case 1: 
		        	System.out.println("Enter a new name in the format <LastName, FirstName> : ");
		        	buffer=in.nextLine();
		        	name=in.nextLine();
		        	System.out.println("Enter the home address in the format <StreetAddress, City, State, ZipCode> :");
		        	address=in.nextLine();
		        	System.out.println("Enter the phone number in the format: <XXXXXXXXX>");
		        	phone=in.nextInt();
		        	dir.insert(name,address,phone);
		        	dir.sort();
		        	break;
		        case 2:
		        	dir.display();
		        	break;
		        case 3:
		        	System.out.println("Enter the search query: ");
		        	buffer=in.nextLine();
		        	name=in.nextLine();
		        	dir.search(name);
		        	break;
		        case 4:
		        	ex=true;
		        	break;
		        default: 
		        	System.out.println("INVALID CHOICE. PLEASE TRY AGAIN");		       		        	        
 	        }
 	        if(ex)
 	        	break;
       }           
        in.close();
    }
}
      
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
  