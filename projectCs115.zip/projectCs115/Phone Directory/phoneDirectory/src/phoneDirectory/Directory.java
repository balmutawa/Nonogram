package phoneDirectory;

/**
 *class to implement the directory
 *
 * Basel Almutawa
 * sep/13
 */


public class Directory
{
	
	int elements, currentSize;
	Entry []entries;

	//set the directory size
	public Directory (int name) 
	{
		elements=name;
		entries= new Entry [elements];
		currentSize=0;
	}
	
	//insert the passed values as an Entry in the directory
	public void insert (String name, String address, int phone) 
	{
		if(elements==currentSize)
		{
			System.out.println("The Directory is full. Insertion has failed");
			return;
		}
		entries[currentSize]=new Entry(name,name,address,phone);
		currentSize++;
		System.out.println("Insertion has succeeded.");
	}
	
	//sort the directory by Name
	public void sort() 
	{
		int i,j = 0,min = 0;
		String s1,s2;
		for (i=0;i<currentSize-1;i++) 
		{
			min=i;
			for (j=i+1;j<currentSize;j++) 
			{
				s1=entries[min].getFullName();
				s2=entries[j].getFullName();
				if (s1.compareTo(s2)>0)
				min=j;
			}
			if (min!=i) 
			{
				Entry p=entries[min];
				entries[min]=entries[i];
				entries[i]=p;
			}
		}
	}

	//display the entire directory
	public void display () 
	{
		int i;
		for (i=0;i<currentSize;i++)
			System.out.println(entries[i].getFullName()+ "\t\t"+ entries[i].getFullAddress()+"\t\t"+entries[i].getPhoneNumber());
	}
	
	//search for a specific element in array
	public void search (String s) 
	{
		int i;
		for (i=0;i<currentSize;i++)
		{
			if (entries[i].getFullName().equalsIgnoreCase(s))
			{
				System.out.println(entries[i].getFullName()+ "\t\t"+ entries[i].getFullAddress()+"\t\t"+ entries[i].getPhoneNumber());
				return;
			}
		}
		System.out.println(s + "not found in directory");
	}

	public String toString() {
		System.out.println ("Current entries: ");
		for (Entry entry:entries)
		{
			System.out.print ("Name: " + entry.getFullName());
		}
		return "";
		
	}

		
}


