package phoneDirectory;


/**
 *class to hold the information about the directory entries 
 *
 * Basel Almutawa
 * sep/13
 */
public class Entry
{
    private String fullName;
    private String fullAddress;
    private int phoneNumber;
    public Entry(String name,String name2, String address, int phone)
    {
    	fullName = name;
    	fullAddress = address;
    	phoneNumber = phone;
    }
    
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getFullAddress() {
		return fullAddress;
	}
	public void setFullAddress(String fullAddress) {
		this.fullAddress = fullAddress;
	}
	public int getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(int phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
    public String toString () {
    	return"";
    }
    
}


    
    

