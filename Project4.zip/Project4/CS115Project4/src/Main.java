import java.util.Scanner;

/**
 * Project4 Main class 
 *
 * @author Basel Almutawa
 * @version 1.0 and Oct 18th 2021 
 */
public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Please enter a number to see Pascal Triangle: ");
        int N = input.nextInt();
        PascalTriangle obj = new PascalTriangle();
        System.out.println("Pascal's Triangle is bellow:\n");
        obj.generatePascalTriangle(N);
    }
}
