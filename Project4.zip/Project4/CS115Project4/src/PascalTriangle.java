/**
 * PascalTriangle class 
 *
 * @author Basel Almutawa
 * @version 1.0 and Oct 18th 2021 
 */
public class PascalTriangle {
    /**
     * This will generate one row at a time
     * @param current
     * @param cur 
     */
    private void pascalTriangleRow(int [][]current, int cur){
        if(cur < current.length){
            current[cur] = new int[cur+1];
            current[cur][0] = 1;
            current[cur][current[cur].length-1] = 1;
            for(int i = 1; i < current[cur].length-1;i++){
                current[cur][i] = current[cur-1][i-1] + current[cur-1][i];
            }
            pascalTriangleRow(current, cur+1);
        }
    }
    /**
     * This method generate and display the triangle
     * @param N 
     */
    public void generatePascalTriangle(int N){
        if(N <= 0){
            return;
        }
        int [][]triangle = new int[N][];
        triangle[0] = new int[1];
        triangle[0][0] = 1;
        pascalTriangleRow(triangle, 1);
        // now print
        for(int i =0; i < triangle.length; i++){
            for(int k = 1; k<(triangle.length-i);k++){
                System.out.print("     ");
            }
            for(int j = 0; j < triangle[i].length; j++){
                System.out.printf("%-10d", triangle[i][j]);
            }
            System.out.println();
        }
    }
}
