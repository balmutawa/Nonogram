
import java.util.Scanner;

/**
 * Project3_Q1 class 
 *
 * @author Basel Almutawa
 * @version 1.0 and Oct 18th 2021 
 */
public class Project3_Q1 {
    public static void main(String []args){
        // sort integer
        Sorting<Integer> sort = new Sorting<>();
        Integer []data = new Integer[10];
        // get random number
        for(int i=0;i<data.length;i++) 
            data[i] = (int)(Math.random()*(20));
        // run insertion sort
        sort.insertionSort(data);
        // print value
        System.out.println(getArrayString(data));
        
        // sort string 
        Sorting<String> sort2 = new Sorting<>();
        // get string array
        String []dataStr = {"loves", "hates", "sees", "knows", "looks for", "finds","XYZ", "man", "woman", "fish", "elephant", "unicorn"};
        // run selection sort
        sort2.selectionSort(dataStr);
        // print array
        System.out.println(getArrayString(dataStr));
    }
    /**
     * Static print any comparable object
     * @param <T>
     * @param a
     * @return 
     */
   public static<T> String getArrayString(Comparable<T> []a)
  {
    String s = "[" + a[0];
    // go over the elments
    for(int i=1;i<a.length;i++)
    {
      s += ", " + a[i];
    }
    s += "]";
    return s;
  }
}
