
import java.util.Scanner;

/**
 * Project3_Q2 class 
 *
 * @author Basel Almutawa
 * @version 1.0 and Oct 18th 2021 
 */
public class Project3_Q2 {
    public static void main(String []args){
        Scanner input = new Scanner(System.in);
         char yn;
         /// keep dong it
        do{
            // get input
            System.out.print("Enter the document designation: ");
            String doc = input.next().toUpperCase();
            // check if valid 
            if(doc.charAt(0) == 'U' || doc.charAt(0) == 'C' || doc.charAt(0) == 'P'){
                System.out.println("Correct designation");
            }else{
                // thorw exeption
                throw new InvalidDocumentCodeException(
                        "Document has to be Unclassified, Confidential or Proprieary", 
                        new RuntimeException());
            }
            // ask if user want to try again
            System.out.print("\nDo you want to do more: ");
            yn = input.next().toLowerCase().charAt(0);
        }while(yn == 'y');
    }
}
