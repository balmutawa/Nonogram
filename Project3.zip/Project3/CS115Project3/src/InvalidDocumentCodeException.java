/**
 * InvalidDocumentCodeException class 
 *
 * @author Basel Almutawa
 * @version 1.0 and Oct 18th 2021 
 */
public class InvalidDocumentCodeException extends RuntimeException{
    public InvalidDocumentCodeException(String error, Throwable err){
        super(error,err);
    }
}
