
import java.util.Scanner;

/**
 * Project3_Q3 class 
 *
 * @author Basel Almutawa
 * @version 1.0 and Oct 18th 2021 
 */
public class Project3_Q3 {
    public static void main(String []args){
        Scanner input = new Scanner(System.in);
        char yn;
        do{
            // get input
            System.out.print("Enter the document designation: ");
            String doc = input.next().toUpperCase();
            try{
                // check if its valid 
                if(doc.charAt(0) == 'U' || doc.charAt(0) == 'C' || doc.charAt(0) == 'P'){
                    System.out.println("Correct designation");
                }else{
                    // if not valid throw exception
                    throw new InvalidDocumentCodeException(
                            "Document has to be Unclassified, Confidential or Proprieary", 
                            new RuntimeException());
                }
                // catch if exception is thrown
            }catch(InvalidDocumentCodeException ex){
                System.out.println("Caught the expection");
            }
            // ask user if they want to try again
            System.out.print("\nDo you want to do more: ");
            yn = input.next().toLowerCase().charAt(0);
        }while(yn == 'y');
        System.out.println("Program exited normally");
    }
}
