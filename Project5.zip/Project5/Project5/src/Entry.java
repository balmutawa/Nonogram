/**
 * Entry class 
 *
 * @author Basel Almutawa
 * @version 1.0 and Dec 6th 2021
 */

public class Entry
{
    private String fullName;
    private String fullAddress;
    private String phone;
     public Entry(String name, String address, String phoneNumber) //Constructor
    {
        fullName = name;
        fullAddress = address;
        phone = phoneNumber;
    }
    public String getName(){return fullName;} //Returns the name associated with the entry
    public void setName(String n){fullName = n;} //Changes the name associated with the entry
    public String getAddress(){return fullAddress;} //Returns the address associated with the entry
    public void setAddress(String a){fullAddress = a;} //Changes the name associated with the entry
    public String getPhone(){return phone;} //Returns the phone number associated with the entry
    public void setPhone(String p){phone = p;} //Changes the phone number associated with the entry
    public String toString(){return "Name: " + fullName + ", Address: " + fullAddress + ", Phone Number: " + phone;} //Returns the whole entry in string form
}
