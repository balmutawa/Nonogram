/**
 * Directory class 
 *
 * @author Basel Almutawa
 * @version 1.0 and Dec 6th 2021
 */

import java.util.LinkedList;


public class Directory {
    private LinkedList<Entry> dic;

    public Directory() {
        dic = new LinkedList<>();
    }
    
    public void insert(Entry et){
        for(int i =0 ;i < dic.size();i++){
            if(dic.get(i).getName().compareTo(et.getName())>=0){
                dic.add(i, et);
                return;
            }
        }
        dic.add(et);
    }
    
    public void delete(String name){
        for(int i =0 ;i < dic.size();i++){
            if(dic.get(i).getName().equalsIgnoreCase(name)){
                System.out.println("Successfully deleted:\n"+dic.get(i));
                dic.remove(i);
                return;
            }
        }
        System.out.println("Deletion Failed!\nDidn't find any entry with name: "+name);
        System.out.println();
    }
    
    public String toString(){
        String st = "======================== All Entries ===========================\n";
        for(Entry e:dic){
            st += e.toString()+"\n";
        }
        st += "\n--------------------------------------------------------------";
        return st;
    }
    
    public void search(String name){
        for(int i =0 ;i < dic.size();i++){
            if(dic.get(i).getName().equalsIgnoreCase(name)){
                System.out.println("Successfully found:\n"+dic.get(i));
                return;
            }
        }
        System.out.println("Search Failed!\nDidn't find any entry with name: "+name);
        System.out.println();
    }
}
