/**
 * Driver class 
 *
 * @author Basel Almutawa
 * @version 1.0 and Dec 6th 2021
 */
import java.util.Scanner;
public class Driver
{
    public static void main(String[] args)
    {
        Scanner scan = new Scanner(System.in);
        boolean run = true; //Make a bool to run our while loop later
        String command; //Make a string to store user commands in later
        Directory dir = new Directory(); //Create the directory with size based on user input
        while(run)
        {
            System.out.println("Please enter a command or enter 'help' to display a list of commands.");
            command = scan.nextLine().toLowerCase().trim(); //Read the user input
            switch(command) //Perform different functions depending on user input
            {
                case("help"): help(); break; //Prints instructions to screen
                case("insert"): insert(scan, dir); break; //Prompts user for some info then creates a new entry
                case("delete"): delete(scan, dir); break; //Prompts user for some info then delete for an entry
                case("search"): search(scan, dir); break; //Prompts user for some info then searches for an entry
                case("display"): System.out.println(dir.toString()); break; //Prints the whole directory to screen
                case("quit"): run = false; break; //Ends the loop
                default: break; //Nothing happens if they enter something that isn't a valid command
            }
        }
    }
    
    public static void help() //Helper method to print out instructions for user
    {
        System.out.println("Enter 'insert' to add an entry, "
                + "\n'search' to find and show an existing entry, \n"
                + "'display' to show the entire directory, \n"
                + "'delete' to delete an entry from directory, \n"
                + "or 'quit' to end the program.");
    }

    public static void insert(Scanner scan, Directory dir) //Helper method that does all the insert stuff
    {
        System.out.println("Please enter the full name of the person to enter.");
        String name = scan.nextLine(); //Get name from user
        System.out.println("Please enter the full address of the person to enter.");
        String address = scan.nextLine(); //Get address from user
        System.out.println("Please enter the phone number of the person to enter.");
        String phone = scan.nextLine(); //Get phone number from user
        dir.insert(new Entry(name, address, phone)); //Create entry with characteristics from above
    }
    
    public static void search(Scanner scan, Directory dir) //Helper method that searches
    {
        System.out.println("Please enter the full name of the person to search for.");
        String name = scan.nextLine(); //Get name from user
        dir.search(name); //Search directory using the name from above
    }
    
    public static void delete(Scanner scan, Directory dir) //Helper method that searches
    {
        System.out.println("Please enter the full name of the person to remove.");
        String name = scan.nextLine(); //Get name from user
        dir.delete(name); //Search directory using the name from above
    }
}
